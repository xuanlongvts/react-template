import React from 'react';

export default () => (
    <div className="notFound">
        <p className="txtIntro">Not Found</p>
    </div>
);
