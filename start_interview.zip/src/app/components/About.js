import React, { PureComponent } from 'react';

class About extends PureComponent {
    render() {
        return (
            <div>
                <p className="txtIntro">About</p>
            </div>
        );
    }
}

export default About;
