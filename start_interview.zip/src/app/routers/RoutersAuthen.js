import { lazy } from 'react';

import RouterMain from './consts';
import AsyncComponent from '../components/_asynComponent';

const AsyncHome = AsyncComponent(lazy(() => import('../components/Home')));
const AsyncAbout = AsyncComponent(lazy(() => import('../components/About')));

const routersAuthen = [
    {
        title: 'Home',
        path: RouterMain.home,
        component: AsyncHome,
        exact: true,
    },
    {
        title: 'About',
        path: RouterMain.about,
        component: AsyncAbout,
    },
];

export default routersAuthen;
