const home = '/';
const about = '/about';

export default {
    home: home,
    about: about,
};
